import xbmcaddon

MainBase = 'https://raw.githubusercontent.com/mcktvkodi/mcktvrepo/master/main.xml'
addon = xbmcaddon.Addon('plugin.video.mcktvsports')