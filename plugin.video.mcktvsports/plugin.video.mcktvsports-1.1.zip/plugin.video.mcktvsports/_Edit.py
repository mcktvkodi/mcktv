import xbmcaddon

MainBase = 'http://bit.ly/1SP0G4e'
addon = xbmcaddon.Addon('plugin.video.mcktvsports')