import xbmcaddon

MainBase = 'http://bit.ly/1qk72Rc'
addon = xbmcaddon.Addon('plugin.video.mcktvsports')